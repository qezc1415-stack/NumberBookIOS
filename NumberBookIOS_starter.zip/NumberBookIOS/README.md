# NumberBook iOS — starter project

This is a native SwiftUI starter reconstructed from the supplied Android APK's visible feature clues (search, history, settings). It is **not** the original NumberBook iOS app and does not implement the original server lookup.

## Build and sign on your Mac
1. Open `NumberBookIOS.xcodeproj` in Xcode.
2. Select the `NumberBookIOS` target → Signing & Capabilities.
3. Enable Automatically manage signing and choose your Apple Developer Team.
4. Change `com.example.NumberBookIOS` to a unique Bundle Identifier you control.
5. Select a connected iPhone or a generic iOS device and Build.
6. For a direct-install IPA: Product → Archive, then Distribute App. Ad Hoc distribution requires the target iPhone UDID to be registered in the Apple Developer account. Alternatively use TestFlight for tester distribution.

## Important limits
- The supplied ZIP is an extracted Android APK (DEX/resources/Android manifest), not an Xcode project.
- This starter intentionally does not connect to the legacy NumberBook endpoints, upload contacts, or intercept calls/SMS.
- A real number-lookup service requires lawful access to a working API, authentication, privacy disclosures, and server-side compatibility. iOS does not permit Android-style SMS/call interception.
- No IPA or signed certificate profile has been generated here; signing must occur in Xcode on your Mac using your own developer account.
