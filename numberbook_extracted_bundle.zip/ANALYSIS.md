# NumberBook APK – extraction and reverse-engineering notes

## Input
- File: memo00066.apk
- SHA-256: 9b9ce9b302b42ab057f1360fb598ce21ad7f4fd96ce29661a08e10779c46e7a8
- APK size: 1,915,438 bytes
- ZIP entries: 800

## Verified package contents
- AndroidManifest.xml: present (9,688 bytes; Android binary XML)
- resources.arsc: present (147,216 bytes; compiled Android resources)
- classes.dex: present (871,028 bytes; Dalvik bytecode)
- Layout XML resources: 91 (compiled Android XML resources)
- Raster images: 644
- Secondary DEX files: 0

## Layout resource names
- `res/layout/abs__action_bar_home.xml`
- `res/layout/abs__action_bar_tab.xml`
- `res/layout/abs__action_bar_tab_bar_view.xml`
- `res/layout/abs__action_bar_title_item.xml`
- `res/layout/abs__action_menu_item_layout.xml`
- `res/layout/abs__action_menu_layout.xml`
- `res/layout/abs__action_mode_bar.xml`
- `res/layout/abs__action_mode_close_item.xml`
- `res/layout/abs__activity_chooser_view.xml`
- `res/layout/abs__activity_chooser_view_list_item.xml`
- `res/layout/abs__dialog_title_holo.xml`
- `res/layout/abs__list_menu_item_checkbox.xml`
- `res/layout/abs__list_menu_item_icon.xml`
- `res/layout/abs__list_menu_item_layout.xml`
- `res/layout/abs__list_menu_item_radio.xml`
- `res/layout/abs__popup_menu_item_layout.xml`
- `res/layout/abs__screen_action_bar.xml`
- `res/layout/abs__screen_action_bar_overlay.xml`
- `res/layout/abs__screen_simple.xml`
- `res/layout/abs__screen_simple_overlay_action_mode.xml`
- `res/layout/abs__search_dropdown_item_icons_2line.xml`
- `res/layout/abs__search_view.xml`
- `res/layout/abs__simple_dropdown_hint.xml`
- `res/layout/actionbar_add_button.xml`
- `res/layout/actionbar_custom_view_add_showlist.xml`
- `res/layout/actionbar_custom_view_disclaimer.xml`
- `res/layout/actionbar_custom_view_done_discard.xml`
- `res/layout/actionbar_discard_button.xml`
- `res/layout/actionbar_done_button.xml`
- `res/layout/actionbar_list_button.xml`
- `res/layout/actionbar_list_terms.xml`
- `res/layout/actionbar_proceed_button.xml`
- `res/layout/activationdialog.xml`
- `res/layout/app_msg.xml`
- `res/layout/blacklist_fragment_layout.xml`
- `res/layout/blocksms_fragment_layout.xml`
- `res/layout/captcha.xml`
- `res/layout/checkcontactslayout.xml`
- `res/layout/com_facebook_friendpickerfragment.xml`
- `res/layout/com_facebook_login_activity_layout.xml`
- `res/layout/com_facebook_picker_activity_circle_row.xml`
- `res/layout/com_facebook_picker_checkbox.xml`
- `res/layout/com_facebook_picker_image.xml`
- `res/layout/com_facebook_picker_list_row.xml`
- `res/layout/com_facebook_picker_list_section_header.xml`
- `res/layout/com_facebook_picker_search_box.xml`
- `res/layout/com_facebook_picker_title_bar.xml`
- `res/layout/com_facebook_picker_title_bar_stub.xml`
- `res/layout/com_facebook_placepickerfragment.xml`
- `res/layout/com_facebook_placepickerfragment_list_row.xml`
- `res/layout/com_facebook_usersettingsfragment.xml`
- `res/layout/countrylist.xml`
- `res/layout/create_list_layout.xml`
- `res/layout/create_profile_layout.xml`
- `res/layout/enter_password_dialog.xml`
- `res/layout/historyitem.xml`
- `res/layout/home_layout.xml`
- `res/layout/joke_detail_activity_layout.xml`
- `res/layout/joke_detail_fragment_layout.xml`
- `res/layout/list_item_call_log.xml`
- `res/layout/list_sms.xml`
- `res/layout/logmanager_fragment_layout.xml`
- `res/layout/messagerow.xml`
- `res/layout/password_dialog.xml`
- `res/layout/phone_number_dialog.xml`
- `res/layout/rate_dialog_layout.xml`
- `res/layout/row.xml`
- `res/layout/search.xml`
- `res/layout/search_results_activity_layout.xml`
- `res/layout/search_results_fragment_layout.xml`
- `res/layout/searchresults.xml`
- `res/layout/selection_row.xml`
- `res/layout/settings_fragment_layout.xml`
- `res/layout/sherlock_spinner_dropdown_item.xml`
- `res/layout/sherlock_spinner_item.xml`
- `res/layout/sms_enter_message.xml`
- `res/layout/sms_row.xml`
- `res/layout/smsmanager_fragment_layout.xml`
- `res/layout/splash_layout.xml`
- `res/layout/terms_layout.xml`
- `res/layout/text_number_dialog.xml`
- `res/layout/toast_image_left.xml`
- `res/layout/w.xml`
- `res/layout/whitelist_fragment_layout.xml`
- `res/layout-v14/sherlock_spinner_dropdown_item.xml`
- `res/layout-v14/sherlock_spinner_item.xml`
- `res/layout-large/abs__action_mode_close_item.xml`
- `res/layout-xlarge/abs__screen_action_bar.xml`
- `res/layout-xlarge/abs__screen_action_bar_overlay.xml`
- `res/layout-ar/phone_number_dialog.xml`
- `res/layout-ar/search.xml`

## Endpoints and service URLs found as strings in classes.dex
These are embedded string references only. Their current availability and behavior have not been tested.
- `http://co.contramain.co`
- `http://developers.facebook.com/docs/reference/rest/`
- `http://download.numberbook.org`
- `http://promanage.promanageapp.com/`
- `http://www.numberbook.org/terms/faq.html`
- `https://.facebook.com`
- `https://api.facebook.com/method/`
- `https://api.facebook.com/restserver.php`
- `https://api.negusa.info/gab/ackSms.aspx`
- `https://api.negusa.info/gab/captcha.aspx`
- `https://api.negusa.info/gab/checkbill.aspx`
- `https://api.negusa.info/gab/getnamenew.aspx`
- `https://api.negusa.info/gab/reg.aspx`
- `https://api.negusa.info/gab/regpush.aspx`
- `https://api.negusa.info/gab/synch.aspx`
- `https://api.negusa.info/gab/unban.aspx`
- `https://api.negusa.info/tc/acceptablePolicy.html`
- `https://api.negusa.info/tc/privacy.html`
- `https://api.negusa.info/tc/terms-and-conditions.html`
- `https://api.negusa.info/unlist/IDS.ASPX`
- `https://api.negusa.info/unlist/unlist.aspx`
- `https://api.numberbook.org/secureand/getpush.aspx`
- `https://facebook.com`
- `https://graph.facebook.com`
- `https://graph.facebook.com/`
- `https://graph.facebook.com/%s/picture`
- `https://m.facebook.com/dialog/`

## Rebuild implications
This is an Android APK, not an iOS project. The DEX bytecode and compiled Android resources are not directly reusable as a native iOS app. A compatible iOS implementation must be recreated (for example with SwiftUI/UIKit), and server-dependent features require working APIs and compatible authentication. iOS also restricts several Android-style call/SMS interception and blocking capabilities.

## Work completed
- Extracted all APK entries into this folder.
- Confirmed presence of manifest, resource table, and DEX bytecode.
- Indexed layout resource names and URL strings for the next reverse-engineering pass.

## Not completed
- DEX decompilation into readable Java/Kotlin source.
- Decoding Android binary XML/resource table into readable XML.
- Native iOS implementation, Xcode build, code signing, or IPA generation.
